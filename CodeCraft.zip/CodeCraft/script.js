document.addEventListener('DOMContentLoaded', function() {
    const passwordInput = document.querySelector('#password');
    const passwordError = document.querySelector('#password-error');
    
    passwordInput.addEventListener('input', function() {
        const password = passwordInput.value;
        
        if (validatePassword(password)) {
            passwordError.textContent = '';
        } else {
            passwordError.textContent = 'Password must be at least 6 characters long and contain both letters and numbers.';
        }
    });
    
    function validatePassword(password) {
        // Minimum length of 6 characters
        if (password.length < 6) {
            return false;
        }
        
        // Check for at least one letter and one number
        const hasLetter = /[a-zA-Z]/.test(password);
        const hasNumber = /\d/.test(password);
        
        return hasLetter && hasNumber;
    }
});

//Email Validation
document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.getElementById('email');
    const emailError = document.getElementById('email-error');

    emailInput.addEventListener('input', function() {
        const email = emailInput.value;

        if (validateEmail(email)) {
            emailError.textContent = '';
        } else {
            emailError.textContent = 'Please enter a valid email address.';
        }
    });

    function validateEmail(email) {
        // Basic email validation using a regular expression
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
        return emailPattern.test(email);
    }
});
